package com.example.guidinglight_opsc_part_2_group_5;

public class SettingClass {
    public String setting;

    public SettingClass()
    {
    }

    public SettingClass(String setting) {
        this.setting = setting;
    }

    public String getSetting()
    {
        return setting;
    }

    public void setSetting(String setting)
    {
        this.setting = setting;
    }
}


