package com.example.guidinglight_opsc_part_2_group_5;

public class save {
    public String place;

    public save()
    {
    }

    public save(String place)
    {
        this.place = place;
    }

    public String getPlace()
    {
        return place;
    }

    public void setPlace(String place)
    {
        this.place = place;
    }
}